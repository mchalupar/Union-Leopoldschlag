/**
 *	com_simplecalendar - a simple calendar component for Joomla
 *  Copyright (C) 2008-2009 Fabrizio Albonico
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
 
 
 Hello and thank you for downloading and trying my SimpleCalendar. Please be aware that this is not a professional product, so bugs and/or minor problems can be expected. If you find a bug, please report it to the author by writing a post in our Forum (http://software.albonico.ch/phpBB). Thank you.
 If you have questions or suggestions, I would like to hear from you: please leave a message on my website: http://software.albonico.ch/
 
 Copyright notice: please do not remove or alter the copyright notice and the link pointing to http://software.albonico.ch/. Thank you very much.

 Have fun!
 
 
 /* CHANGELOG */
 
 There is an up-to-date changelog on the support forum. Refer to this post for more information:
 http://software.albonico.ch/phpBB/viewtopic.php?f=3&t=2
 

 /* CREDITS */

 Please see the CREDITS.txt file that should come with this component.