<?php
/**
 * @version		$Id: $
 * @author		Nguyen Dinh Luan
 * @package		Joomla!
 * $subpackage	Dropline_Menu
 * @copyright	Copyright (C) 2008 - 2011 Joomseller Solutions. All rights reserved.
 * @license		GNU/GPL http://www.gnu.org/licenses/gpl.html, see LICENSE.txt
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

class modDropLineMenu {

	function createParameterObject($param, $path='', $type='menu') {
		if(defined( '_JEXEC' )) return new JParameter($param, $path);
		else return new mosParameters($param, $path, $type);
	}

	// get main menu item
	function getAllMenuItems($menutype) {
		global $Itemid;
	    $db	= &JFactory::getDBO();
		$id	= $Itemid;

		while (1) {
			$sql = "SELECT m1.id"
				." FROM #__menu AS m1"
				." INNER JOIN #__menu AS m2 ON (m1.id = m2.parent AND m2.id = " . $id . ")"
				." WHERE m1.published = 1"
				." ORDER BY m1.ordering";

			$db->setQuery($sql);
			if ($db->loadResult()) {
				$id = $db->loadResult();
			} else {
				break;
			}
		}

		$sql = "SELECT *"
			." FROM #__menu AS m"
			." WHERE m.menutype='".$menutype."' && m.parent = 0 AND m.published = 1"
			." ORDER BY m.ordering";

		$db->setQuery($sql);
		$rows = $db->loadObjectList();
		
		if ($n = count($rows)) {
			for ($i = 0; $i < $n; $i++) {
				$this->makecorrectlink($rows[$i]);
				$this->makecorrectNav($rows[$i]);
				$rows[$i]->subs = $this->getSublevel($rows[$i]->id); //Get the first sublevel of main item i
				$rows[$i]->active = $rows[$i]->id==$id?1:0;
				$rows[$i]->li_id = 'ItemID_'.$rows[$i]->id;
				$rows[$i]->right_ul = ($i>($n/2))?1:0;
			}
		}
		return $rows;
	}
	
	function makecorrectlink(&$row) {
		
		switch ($row->type) {
			case 'separator' :
				// No further action needed.
				break;
			case 'url' :
				if ((strpos($row->link, 'index.php?') !== false) && (strpos($row->link, 'Itemid=') === false)) {
					$row->link = $row->link.'&amp;Itemid='.$row->id;
				}
				break;
			default :
				$router = JSite::getRouter();
				$row->link = $router->getMode() == JROUTER_MODE_SEF ? 'index.php?Itemid='.$row->id : $row->link.'&Itemid='.$row->id;
				break;
		}
	}
	
	function makecorrectNav(&$row) {
		switch ($row->browserNav) {
			case 0:
				$row->browserNav = '';
				break;
			case 1:
				$row->browserNav = 'target="_blank"';
				break;
			case 2:
				$row->browserNav = 'onclick="window.open(this.href,\'targetWindow\',\'toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes,\');return false;"';
		}
	}
	
	function getSublevel($id) {
		global $Itemid;
		$db 	=& JFactory::getDBO();
		//Get menu level 2
		$sql = "SELECT *"
			." FROM #__menu AS m"
			." WHERE m.parent = ".$id." AND m.published = 1 ". $this->getaccess('m')
			." ORDER BY m.ordering";
		$db->setQuery($sql);
		$rows = $db->loadObjectList();
		for ($i=0;$i<count($rows);$i++) {
			$this->makecorrectlink($rows[$i]);
			$this->makecorrectNav($rows[$i]);
			$rows[$i]->active = $rows[$i]->id==$Itemid?1:0;
		}
		return $rows;
	}
	
	function getaccess($prex) {
		$user	= &JFactory::getUser();
		$access	= (int)$user->get('gid');
		$text = " AND $prex.access <= $access";
		return $text;
	}
}